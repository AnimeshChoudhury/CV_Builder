"""
Google Scholar Integration for CV Builder
Fetches publications from Google Scholar profile

NOTE: This requires the 'scholarly' package to be installed:
      pip install scholarly

This script can be run separately to fetch your publications and save them
to the cv_data.json file.
"""

import json
import os


def fetch_scholar_publications(scholar_id):
    """
    Fetch publications from Google Scholar profile
    
    Args:
        scholar_id: Your Google Scholar user ID (from your profile URL)
                   Example: scholar.google.com/citations?user=YOUR_ID_HERE
    
    Returns:
        List of publication dictionaries
    """
    try:
        from scholarly import scholarly
        
        print(f"Fetching publications for Scholar ID: {scholar_id}")
        print("This may take a minute...")
        
        # Search for the author
        author = scholarly.search_author_id(scholar_id)
        author = scholarly.fill(author, sections=['publications'])
        
        publications = []
        
        for pub in author['publications']:
            # Fill in details for each publication
            try:
                filled_pub = scholarly.fill(pub)
                
                # Extract relevant information
                pub_data = {
                    "title": filled_pub['bib'].get('title', 'Untitled'),
                    "authors": filled_pub['bib'].get('author', 'Unknown'),
                    "venue": filled_pub['bib'].get('venue', filled_pub['bib'].get('journal', 'Unknown venue')),
                    "year": int(filled_pub['bib'].get('pub_year', 0)),
                    "citations": filled_pub.get('num_citations', 0),
                    "type": "journal" if 'journal' in filled_pub['bib'] else "conference"
                }
                
                publications.append(pub_data)
                print(f"  ✓ {pub_data['title'][:60]}... ({pub_data['year']})")
                
            except Exception as e:
                print(f"  ✗ Error processing publication: {e}")
                continue
        
        # Sort by year (most recent first)
        publications.sort(key=lambda x: x['year'], reverse=True)
        
        print(f"\n✓ Successfully fetched {len(publications)} publications")
        return publications
        
    except ImportError:
        print("ERROR: 'scholarly' package not installed.")
        print("Please install it using: pip install scholarly")
        return []
    except Exception as e:
        print(f"ERROR: Failed to fetch publications from Google Scholar: {e}")
        return []


def update_cv_with_scholar_data(scholar_id, json_file="cv_data.json"):
    """
    Fetch publications from Google Scholar and update cv_data.json
    
    Args:
        scholar_id: Your Google Scholar user ID
        json_file: Path to cv_data.json file
    """
    # Fetch publications
    publications = fetch_scholar_publications(scholar_id)
    
    if not publications:
        print("No publications fetched. CV data not updated.")
        return
    
    # Load existing CV data
    if os.path.exists(json_file):
        with open(json_file, 'r', encoding='utf-8') as f:
            cv_data = json.load(f)
    else:
        print(f"ERROR: {json_file} not found. Please run cv_builder.py first.")
        return
    
    # Update publications
    cv_data['publications'] = publications
    
    # Save updated data
    with open(json_file, 'w', encoding='utf-8') as f:
        json.dump(cv_data, f, indent=2, ensure_ascii=False)
    
    print(f"\n✓ CV data updated with {len(publications)} publications")
    print(f"✓ Saved to {json_file}")
    print("\nYou can now run cv_builder.py to regenerate your CV with updated publications.")


def get_scholar_id_from_url(url):
    """
    Extract Scholar ID from Google Scholar profile URL
    
    Args:
        url: Full Google Scholar profile URL
        
    Returns:
        Scholar ID string
    """
    if "user=" in url:
        return url.split("user=")[1].split("&")[0]
    return url


def main():
    """Main function for Google Scholar integration"""
    print("=" * 70)
    print("Google Scholar Publications Fetcher for CV Builder")
    print("=" * 70)
    
    print("\nThis script fetches your publications from Google Scholar")
    print("and updates your cv_data.json file.")
    
    print("\nTo find your Scholar ID:")
    print("1. Go to your Google Scholar profile")
    print("2. Look at the URL: scholar.google.com/citations?user=YOUR_ID_HERE")
    print("3. Copy the YOUR_ID_HERE part")
    
    print("\n" + "-" * 70)
    scholar_input = input("Enter your Google Scholar ID or full profile URL: ").strip()
    
    if not scholar_input:
        print("ERROR: No Scholar ID provided.")
        return
    
    # Extract ID from URL if full URL was provided
    scholar_id = get_scholar_id_from_url(scholar_input)
    
    print(f"\nUsing Scholar ID: {scholar_id}")
    confirm = input("Is this correct? (y/n): ").lower()
    
    if confirm != 'y':
        print("Cancelled.")
        return
    
    # Fetch and update
    update_cv_with_scholar_data(scholar_id)


if __name__ == "__main__":
    main()
